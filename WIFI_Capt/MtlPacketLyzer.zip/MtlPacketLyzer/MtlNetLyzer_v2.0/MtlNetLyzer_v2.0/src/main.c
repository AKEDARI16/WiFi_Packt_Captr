#include "MtlPktLyzer.h"
#include "func_dec.h"
#include "dbgprint.h" 
#include <beacon_parser.h>

int log_level = MSG_MSGDUMP;
int debug_timestamp = 1;
int debug_syslog = 0;
const char *debug_file_path = "./log/cap_debug.log";

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

volatile sig_atomic_t monitor_mode_enabled = 0; // Flag to track monitor mode

void UsageHandler(char *str) {
	printf("Usage: %s [interface] [-h] [-c SSID PWD ] [-p filter] [-s] [other_options]\n", str);
	// Add help message explanations for each option here
	printf("interface: Network interface to monitor.\n");
	printf("-h: Display this help message.\n");
	printf("-c: connect to specific AP/ Router.\n");
	printf("-p: capture packets and Specify a filter string.\n");
	printf("-s: Scan for AP's/Wifi routers around you.\n");
	//added
	printf("-l: Scan Nearby APs with ssi and supported rates\n");
	// Add more
}

void exit_handler()
{
	if (monitor_mode_enabled) {
		const char *interface = "wlp0s20f3";  // Example interface name, replace with actual variable if needed
		set_interface_managed_mode(interface);
    }
	pid_t iPid = getpid(); /* Process gets its id.*/
	debug_close_file();
	kill(iPid, SIGINT); 
	exit(0);
}

int main(int argc, char *argv[]) {
	// Initialization
	int opt;
	char *interface = NULL;
	char *usr_filter = " ";
	char matching_pkt_filter[1000];
	struct bpf_program fp;  // Compiled filter
	u_int8_t thread_creation;
	struct fptr *gfptr = malloc(sizeof(struct fptr));
	debug_open_file(debug_file_path);

	signal(SIGINT,exit_handler);

	if (pthread_mutex_init(&mutex, NULL) != 0 || pthread_cond_init(&cond, NULL) != 0) {
		fprintf(stderr, "Mutex or condition variable initialization failed\n");
		dbg_log(MSG_DEBUG,"Mutex or condition variable initialization failed\n");
		return EXIT_FAILURE;
	}

	// Parse command-line options
	if (argc < 2 || argc > 4) {
		UsageHandler(argv[0]);
		return EXIT_SUCCESS;
	}

	// Check if required arguments are provided
	if (optind < argc) {
		interface = argv[optind++];
	} else {
		dbg_log(MSG_DEBUG,"Error: Missing interface");
		dbg_log(MSG_DEBUG,"Usage: %s <interface> -p <filter>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	printf("optind: %d, argc:%d",optind,argc);
	dbg_log(MSG_DEBUG,"optind: %d, argc:%d",optind,argc);

	//debug_close_file();
	// Open Wi-Fi device for packet capture
	char errbuf[PCAP_ERRBUF_SIZE];
	//pcap_t *handle = pcap_open_live(interface, 8024, 1, 100, errbuf);
	pcap_t *handle = pcap_open_live(interface, MAX_PACKET_LENGTH, PROMISCUOUS_MODE, READ_TIMEOUT_MS, errbuf);
	if (handle == NULL) {
	fprintf(stderr, "Couldn't open device %s: %s\n", interface, errbuf);
		dbg_log(MSG_DEBUG,"Couldn't open device %s: %s\n", interface, errbuf);

	return EXIT_FAILURE;
	}


	//printf("opt: %c", opt);
	while ((opt = getopt(argc, argv, "c:p:hs:w:l")) != -1) {
        switch (opt) {
		case 'c':
		
			/* Assign corresponding functions to function pointers */
			gfptr->bfill_fptr = &connect_capture_thread;
			gfptr->bparse_fptr = &connect_parse_thread;

			//char *filter = "arp or udp or (icmp6 and icmp6[0] == 128) or (ip and (udp or icmp)) or ip6";
			char *usr_filter = "";
			if (pcap_compile(handle, &fp, usr_filter, 0, PCAP_NETMASK_UNKNOWN) == -1) {
				fprintf(stderr, "Couldn't parse filter %s: %s\n", usr_filter, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't parse filter %s: %s\n", usr_filter, pcap_geterr(handle));
				return 1;
			}

			// Set the filter
			if (pcap_setfilter(handle, &fp) == -1) {
				fprintf(stderr, "Couldn't install filter %s: %s\n", usr_filter, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't install filter %s: %s\n", usr_filter, pcap_geterr(handle));
				return 1;
			}
			thread_creation = connect_thread_implement(usr_filter, interface, handle, gfptr);
			printf("call connect thread implementation function");
			dbg_log(MSG_DEBUG,"call connect thread implementation function");
			break;
		case 'p':
		   
			/* Assign corresponding functions to function pointers */
		    	gfptr->bfill_fptr = &packet_capture_thread;
			gfptr->bparse_fptr = &packet_parse_thread;

			//filter = optarg;
			usr_filter = "";
			printf("filter: %s\n",usr_filter);
			dbg_log(MSG_DEBUG,"filter: %s\n",usr_filter);
			if (pcap_compile(handle, &fp, usr_filter, 0, PCAP_NETMASK_UNKNOWN) == -1) {
				fprintf(stderr, "Couldn't parse filter %s: %s\n", usr_filter, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't parse filter %s: %s\n", usr_filter, pcap_geterr(handle));
				exit(EXIT_FAILURE);
			}

			if (pcap_setfilter(handle, &fp) == -1) {
				fprintf(stderr, "Couldn't install filter %s: %s\n", usr_filter, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't install filter %s: %s\n", usr_filter, pcap_geterr(handle));
				exit(EXIT_FAILURE);
			}
			thread_creation = capture_thread_implement(usr_filter, interface, handle, gfptr);
			break;
		case 's':
			
			/* Assign corresponding functions to function pointers */
			gfptr->bfill_fptr = &scan_capture_thread;
			gfptr->bparse_fptr = &scan_parse_thread;
			//char *filter_exp = "arp or udp or (icmp6 and icmp6[0] == 128) or (ip and (udp or icmp)) or ip6";
			char *filter_exp = "";

			if (pcap_compile(handle, &fp, filter_exp, 0, PCAP_NETMASK_UNKNOWN) == -1) {
				fprintf(stderr, "Couldn't parse filter %s: %s\n", filter_exp, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't parse filter %s: %s\n", filter_exp, pcap_geterr(handle));
				return 1;
			}

			// Set the filter
			if (pcap_setfilter(handle, &fp) == -1) {
				fprintf(stderr, "Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
				return 1;
			}
			
    
			
			set_interface_monitor_mode(interface);
			monitor_mode_enabled = 1;
			thread_creation = scan_thread_implement(filter_exp, interface, handle, gfptr);
			break;
			
		case 'w':
			/*gfptr.bfill_fptr = &handshake_capture_thread;
			bparse_fptr = &handshake_parse_thread;*/
			strcpy(matching_pkt_filter, "ether proto 0x888e");
			//char *matching_pkt_filter = "ether proto 0x888e"; // Filter expressi(matching_pkt_filter, "ether proto 0x888e")on for EAPOL frames
			if (pcap_compile(handle, &fp, matching_pkt_filter, 0, PCAP_NETMASK_UNKNOWN) == -1) {
				fprintf(stderr, "Couldn't parse filter %s: %s\n", matching_pkt_filter, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't parse filter %s: %s\n", matching_pkt_filter, pcap_geterr(handle));
				return 1;
			}
			if (pcap_setfilter(handle, &fp) == -1) {
				fprintf(stderr, "Couldn't install filter %s: %s\n", matching_pkt_filter, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't install filter %s: %s\n", matching_pkt_filter, pcap_geterr(handle));
				return 1;
			}
			handshake_implement(matching_pkt_filter, interface, handle);
			break;
		case 'l':
			/* capturing and parsing beacons
			
			*/
			//char *filter_exp = "arp or udp or (icmp6 and icmp6[0] == 128) or (ip and (udp or icmp)) or ip6";
			
			set_interface_monitor_mode(interface);
			monitor_mode_enabled = 1;
			filter_exp = "type mgt and (subtype beacon or subtype probe-resp)";

			if (pcap_compile(handle, &fp, filter_exp, 0, PCAP_NETMASK_UNKNOWN) == -1) {
				dbg_log(MSG_DEBUG,"Couldn't parse filter %s: %s\n", filter_exp, pcap_geterr(handle));
				return 1;
			}


			// Set the filter
			if (pcap_setfilter(handle, &fp) == -1) {
				fprintf(stderr, "Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
				dbg_log(MSG_DEBUG,"Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
				return 1;
			}
			
			thread_creation = beacon_thread_implement(filter_exp, interface, handle, &beacon_parser_thread);
			break;
		case 'h':
			UsageHandler(argv[0]);
			return EXIT_SUCCESS;

		default:
			printf("opt: %c", opt);
			dbg_log(MSG_DEBUG,"opt: %c", opt);
			printf("calling default");
			dbg_log(MSG_DEBUG,"calling default");
			UsageHandler(argv[0]);
			exit(EXIT_FAILURE);
		}	
	}
	set_interface_managed_mode(interface);
	exit_handler();
    return 0;

}
