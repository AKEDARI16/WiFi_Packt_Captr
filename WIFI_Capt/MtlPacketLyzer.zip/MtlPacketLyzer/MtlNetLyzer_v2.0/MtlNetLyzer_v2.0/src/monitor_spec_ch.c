#include <stdio.h>
#include <stdlib.h>

void set_interface_monitor_mode(const char *);

void set_interface_managed_mode(const char *);

void set_interface_monitor_mode(const char *interface_name) {
    char command[100];

    // Bring the interface up
    snprintf(command, sizeof(command), "sudo ifconfig %s down", interface_name);
    if (system(command) != 0) {
        printf("Error: Failed to bring interface up.\n");
        return;
    }

    // Set the interface to monitor mode
    snprintf(command, sizeof(command), "sudo iwconfig %s mode monitor", interface_name);
    if (system(command) != 0) {
        printf("Error: Failed to set interface to monitor mode.\n");
        return;
    }

    // Bring the interface down
    snprintf(command, sizeof(command), "sudo ifconfig %s up", interface_name);
    if (system(command) != 0) {
        printf("Error: Failed to bring interface down.\n");
        return;
    }
    
    printf("interface set to monitor mode");
}


void set_interface_managed_mode(const char *interface_name) {
    char command[100];

    // Bring the interface up
    snprintf(command, sizeof(command), "sudo ifconfig %s down", interface_name);
    if (system(command) != 0) {
        printf("Error: Failed to bring interface up.\n");
        return;
    }

    // Set the interface to monitor mode
    snprintf(command, sizeof(command), "sudo iwconfig %s mode managed", interface_name);
    if (system(command) != 0) {
        printf("Error: Failed to set interface to monitor mode.\n");
        return;
    }

    // Bring the interface down
    snprintf(command, sizeof(command), "sudo ifconfig %s up", interface_name);
    if (system(command) != 0) {
        printf("Error: Failed to bring interface down.\n");
        return;
    }
    
    printf("interface set to managed mode");
}

/*
int main() {
    const char *interface_name = "wlp0s20f3";
    set_interface_monitor_mode(interface_name);
    
    set_interface_managed_mode(interface_name);
    return 0;
}
*/
