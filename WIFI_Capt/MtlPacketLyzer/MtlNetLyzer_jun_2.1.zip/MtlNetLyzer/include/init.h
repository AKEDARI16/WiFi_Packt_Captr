


extern const char *config_filename;  // Global config filename


void init_func(void);
void read_config(const char *);
