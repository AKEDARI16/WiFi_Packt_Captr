#include <stdio.h>
#include <util.h>
#include <ctype.h>
//#include "func_dec.h"
//#include "dbgprint.h" 




